/*
Collin      Hargreaves
CIS 35A          00441
Assignment           5
Due         06-06-2023
Submitted   06-04-2023
*/


This assignment utilizes 
Creating and Using multiple classes in a project
Reading data from a text file
Creating an array of objects based on data from a file
Manipulating an array of objects to make calculations
Utilizing the StringTokenizer to break down each line from a text file
Object Orientated Programming paradigms

How to use

1. compile and execute, no input from user is required
