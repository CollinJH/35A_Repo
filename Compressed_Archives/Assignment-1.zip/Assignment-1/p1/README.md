Collin      Hargreaves <br>
CIS 35A 	     00441 <br>
Assignment          -1 <br>
Due         04-19-2023 <br>
Submitted   04-14-2023 <br>

<h2> Part 1 - Customer Bill </h2>

This program focuses procedural programming, variable types, formatted outputs, taking in input from user, and basic calculations. <br>

The program creates a customer's bill for a company that sells five different products with their each individual price. <br> <br>

<h3> To use the program </h3> <br>
<p>
    1. compile the Part1.java class file to execute <br>
    2. the program will ask you for quantity purchased for each item <br>
    3. after entering quantity of items, the program will calculate the price total of each, subtotal, tax, and grandtotal <br>
    4. finally the program will output everything in a neat format </p>



