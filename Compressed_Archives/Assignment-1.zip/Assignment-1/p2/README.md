Collin      Hargreaves <br>
CIS 35A 	     00441 <br>
Assignment          -1 <br>
Due         04-19-2023 <br>
Submitted   04-14-2023 <br>

<h2> Part 2 - Temperature Converter </h2>

<p> This program uses procedural programming to take input from a user, <br>
then makes calculations with a celicus to fahrenheit formula and vice versa </p>

<h3> To use the program </h3> <br>
<p> 1. compile Part2.java <br>
    2. input value for centigrade to convert <br>
    3. program will output converted to fahrenheit <br>
    4. input value for fahrenheit to convert <br>
    5. program will output converted to celcius </p>

