/*
Collin      Hargreaves
CIS 35A          00441
Assignment           4
Due         05-29-2023
Submitted   05-29-2023
*/

Utilizes polymorphism to showcase how we can create a class ship
and create two separate subclasses that extend the ship
These two subclasses will both have nuances values that only apply to those but will still have the values of Ship

Overriding methods is shown in the displayInfo method for each class

How to use 
1. Compile and execute
2. Look at output