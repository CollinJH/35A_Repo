/*
Collin      Hargreaves
CIS 35A          00441
Assignment           4
Due         05-29-2023
Submitted   05-29-2023
*/

This assignment demonstrates and utilizes
Polymorphism, and demonstrates how it works to extend the methods and properties from one class to another


How to use

1. Simply compile and execute
2. No user input is required