Collin      Hargreaves
CIS 35A          00441
Assignment           2
Due         05-14-2023
Submitted   05-14-2023

This program utilizes Multiple Classes, Class Design, Methods, Scanner I/O, Instance methods, Instance variables, and Formatted Printing
Creating a Driver to utilize created classes, Creating class diagrams, Getters and setters, Constructors, Overloaded Constructors

How to run the program:

1. Compile and execute anyway you like
2. Enter Genome name, Amount of Genes, Amount of Chromosomes, and Amount of Cells as prompted
3. Information will be printed to console
4. This will be repeated twice more before ethe program exits