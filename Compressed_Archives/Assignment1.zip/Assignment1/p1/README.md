Collin      Hargreaves
CIS 35A 	     00441
Assignment           1
Due         04-26-2023
Submitted   04-26-2023

The following Java Project focuses on variable declaration, expression, input using scanner, output formatting
decision making, looping, and methods.

The project will take in three values from the user, loan amount, years, and interest rate,
 and generate an amoratization schedule based on those inputs.

 How to use
 1. run the program
 2. enter loan amount
 3. enter loan years
 4. enter loan interest rate
 5. hit enter and your amoratization schedule will be generated