Collin      Hargreaves
CIS 35A 	     00441
Assignment           1
Due         04-26-2023
Submitted   04-26-2023

The following Java Project focuses on the use of methods, and problem solving

How to use
1. Enter a square root value to approximate
2. Hit enter to calculate