/* 
Collin      Hargreaves
CIS 35A          00441
Assignment           3
Due         05-21-2023
Submitted   05-21-2023
*/

This assignment utilizing
Creating arrays of objects, creating a proper UI class, containment, doing calculations with arrays of objects, switch statement
Multiple java file projects, File input / output, data from a file, creating objects using data from a file.

## How to run program
1. execute and compile Driver.java
2. User will be prompted to enter a store number 1 - 6
3. User will now be prompted to enter a number for an option 1 - 8
4. User will be prompted to continue or not
5. User can continue until they are content with information
6. after choosing not not continue program will exit