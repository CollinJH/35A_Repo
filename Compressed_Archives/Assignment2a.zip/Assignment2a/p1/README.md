/*
Collin      Hargreaves
CIS 35A          00441
Assignment          2a
Due         05-08-2023
Submitted   05-06-2023
*/

This program utilizes Multiple Classes, Class Design, Methods, Scanner I/O, Instance variables, and Formatted Printing, 
Creating class diagrams, Getters and setters, Constructors, Overloaded Constructors

How to run the program:

1. Compile and execute anyway you like
2. Enter name, address, age, and phone number as asked
3. Information will be printed to console
4. This will repeat 2 more times as per the program